package com.jiafei.test;

public interface BooleanListener {
    void doEat(Event event);
}
