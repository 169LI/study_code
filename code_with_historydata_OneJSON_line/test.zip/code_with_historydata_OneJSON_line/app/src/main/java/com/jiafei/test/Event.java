package com.jiafei.test;

public class Event {
        private BooleanClass person;

    public Event() {
    }

    public Event(BooleanClass person) {
        this.person = person;
    }

    public BooleanClass getResource() {
        return person;
    }
}
