package com.jiafei.test;
import java.util.List;
public class Datastreams {
    private List<Datapoints>datapoints;
    private String id;
    public void setDatapoints(List<Datapoints>datapoints){this.datapoints=datapoints;}
    public List<Datapoints> getDatapoints(){return datapoints;}
}
