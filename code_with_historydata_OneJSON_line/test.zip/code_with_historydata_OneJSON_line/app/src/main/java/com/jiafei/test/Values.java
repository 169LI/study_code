package com.jiafei.test;
import java.util.Calendar;
public class Values {
    public static String startDateInfor="";;//请求状态标志位
    public static String startDateInfor_minte="";;//请求状态标志位
    public static BooleanClass booleanClass=new BooleanClass();
    public static BooleanClass booleanClass2=new BooleanClass();
}
